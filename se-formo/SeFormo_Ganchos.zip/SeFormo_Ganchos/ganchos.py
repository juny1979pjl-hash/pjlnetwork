# Se Formo - ganchos automaticos (gratis, corre en tu PC con ffmpeg).
# Vigila OneDrive\Se Formo\ y a cada clip.mp4 nuevo le crea clip_final.mp4 con:
#  - cortinilla de 2 s al inicio (segun el tipo de clip)
#  - sticker "¿Quien tiene la razon?" los primeros 4 s
#  - boton "SIGUEME ¡ES GRATIS!" fijo desde el segundo 4
#  - sticker "¿Quieres la parte 2?" los ultimos 5 s
# Uso:  python C:\SeFormo\ganchos\ganchos.py "CARPETA_DE_LOS_CLIPS"  (sin carpeta = OneDrive\Se Formo)
import os, sys, glob, json, time, subprocess

AQUI = os.path.dirname(os.path.abspath(__file__))
A = lambda f: os.path.join(AQUI, "assets", f)
# Vigila cualquier carpeta de OneDrive (Se Formo, Casa, Mansion...) que tenga clips
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.expanduser("~"), "OneDrive", "*")

PELEA = ["pelea","callate","cállate","respeta","mentira","mentiroso","no me hables","sal de aquí","sal de aqui","que te pasa","qué te pasa","a mí no","a mi no","vete"]
FUERTE = ["coño","mierda","diablo","expulsado","traición","traicion","se formó","se formo"]
RISA = ["jaja","jajaja","broma","risa","jajajaja"]

def tipo(carpeta):
    txt = ""
    p = os.path.join(carpeta, "info.json")
    if os.path.exists(p):
        try:
            d = json.load(open(p, encoding="utf-8"))
            txt = (d.get("txt") or d.get("texto") or json.dumps(d, ensure_ascii=False)).lower()
        except Exception: pass
    cuenta = lambda ws: sum(txt.count(w) for w in ws)
    r, pe, fu = cuenta(RISA), cuenta(PELEA), cuenta(FUERTE)
    if r >= 2 and r >= pe: return "sting_jajaja.mp4"
    if pe >= 2: return "sting_alerta.mp4"
    if fu >= 2: return "sting_seprendio.mp4"
    return "sting_seformo.mp4"

def duracion(f):
    return float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",f],
                                capture_output=True, text=True).stdout.strip())

def hacer(carpeta):
    clip = os.path.join(carpeta, "clip.mp4")
    final = os.path.join(carpeta, "clip_final.mp4")
    sting = A(tipo(carpeta))
    d = duracion(clip)
    fc = (
        "[0:v]scale=1080:1920,setsar=1,fps=30,format=yuv420p[sv];[0:a]aresample=44100,aformat=channel_layouts=stereo[sa];"
        "[1:v]scale=1080:1920,setsar=1,fps=30,format=yuv420p[cv0];[1:a]aresample=44100,aformat=channel_layouts=stereo[ca];"
        "[2:v]format=rgba,fade=t=in:st=0.2:d=0.25:alpha=1,fade=t=out:st=3.6:d=0.3:alpha=1[raz];"
        "[3:v]format=rgba,fade=t=in:st=4:d=0.3:alpha=1[sig];"
        f"[4:v]format=rgba,fade=t=in:st={d-5:.2f}:d=0.3:alpha=1[p2];"
        "[cv0][raz]overlay=x=(W-w)/2:y=980-40*max(0\\,1-(t-0.2)*4):enable='between(t,0,4)':shortest=1[c1];"
        "[c1][sig]overlay=x=W-w-30:y=300+12*sin(t*6):enable='gte(t,4)':shortest=1[c2];"
        f"[c2][p2]overlay=x=(W-w)/2:y=1000:enable='gte(t,{d-5:.2f})':shortest=1[cv];"
        "[sv][sa][cv][ca]concat=n=2:v=1:a=1[v][a]"
    )
    subprocess.run(["ffmpeg","-y","-v","error","-i",sting,"-i",clip,
                    "-loop","1","-i",A("razon.png"),"-loop","1","-i",A("sigueme.png"),"-loop","1","-i",A("parte2.png"),
                    "-filter_complex",fc,"-map","[v]","-map","[a]","-c:v","libx264","-preset","veryfast","-crf","21",
                    "-c:a","aac","-b:a","128k",final], check=True)
    print("LISTO", final, "(", os.path.basename(sting), ")")

if __name__ == "__main__":
    while True:
        for clip in glob.glob(os.path.join(OUT, "*", "clip.mp4")):
            carpeta = os.path.dirname(clip)
            marca = os.path.join(carpeta, "ganchos.lock")
            if os.path.exists(os.path.join(carpeta, "clip_final.mp4")) or os.path.exists(marca): continue
            if time.time() - os.path.getmtime(clip) < 20: continue   # todavia se esta escribiendo
            try:
                open(marca, "x").close()          # evita que dos ventanas hagan el mismo clip
            except FileExistsError:
                continue
            try: hacer(carpeta)
            except Exception as e: print("ERROR", carpeta, e)
            finally:
                try: os.remove(marca)
                except OSError: pass
        time.sleep(15)
