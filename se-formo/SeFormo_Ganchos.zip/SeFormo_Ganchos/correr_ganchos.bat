@echo off
title GANCHOS SE FORMO
:loop
python C:\SeFormo\ganchos\ganchos.py
timeout /t 30 /nobreak >nul
goto loop
