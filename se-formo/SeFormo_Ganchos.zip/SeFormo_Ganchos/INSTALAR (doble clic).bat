@echo off
echo Instalando ganchos de Se Formo...
set D=C:\SeFormo\ganchos
if not exist "%D%" mkdir "%D%"
xcopy /E /Y /Q "%~dp0*" "%D%\" >nul
(echo @echo off& echo start "GANCHOS" /min C:\SeFormo\ganchos\correr_ganchos.bat) > "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SeFormo_Ganchos.bat"
start "GANCHOS" /min "%D%\correr_ganchos.bat"
echo.
echo LISTO. Los ganchos quedan prendidos solos, siempre.
echo Sigue usando tus botones de PRENDER y APAGAR como siempre.
echo En cada clip aparece clip_final.mp4: publica ese.
pause
